import React from "react";
import Dashboard from "./Dashboard";

const UserDashboard = () => {
  return (
    <>
      <Dashboard />
    </>
  );
};

export default UserDashboard;
